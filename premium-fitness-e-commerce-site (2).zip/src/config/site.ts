export const BRAND_NAME = 'MotivateFitness';

// Custom store URL for sharing UI elements
export const PUBLIC_STORE_URL = 'http://motivatefitness.store';

export const APP_BASE_PATH = (import.meta as any).env?.BASE_URL || '/';
