import { Link } from 'react-router-dom';
import { Dumbbell, Instagram, Facebook, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-zinc-900 text-zinc-300 border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-orange-500 to-red-600 p-2 rounded-lg">
                <Dumbbell className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">MotivateFitness</span>
            </Link>
            <p className="text-sm text-zinc-400">
              Premium fitness equipment for serious athletes. Fuel your motivation, forge your strength.
            </p>
            <p className="text-sm text-zinc-500">
              Store link:{' '}
              <a
                href="http://motivatefitness.store"
                className="text-orange-500 hover:text-orange-400"
              >
                http://motivatefitness.store
              </a>
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/shop" className="hover:text-orange-500 transition-colors">Shop All</Link></li>
              <li><Link to="/shop?category=Dumbbells" className="hover:text-orange-500 transition-colors">Dumbbells</Link></li>
              <li><Link to="/shop?category=Barbells" className="hover:text-orange-500 transition-colors">Barbells</Link></li>
              <li><Link to="/shop?category=Squat Racks" className="hover:text-orange-500 transition-colors">Power Racks</Link></li>
              <li><Link to="/about" className="hover:text-orange-500 transition-colors">About Us</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="font-semibold text-white mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link to="/support" className="hover:text-orange-500 transition-colors">Contact Us</Link></li>
              <li><Link to="/support" className="hover:text-orange-500 transition-colors">Shipping Info</Link></li>
              <li><Link to="/support" className="hover:text-orange-500 transition-colors">Returns & Exchanges</Link></li>
              <li><Link to="/support" className="hover:text-orange-500 transition-colors">FAQs</Link></li>
              <li><Link to="/support" className="hover:text-orange-500 transition-colors">Warranty</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-white mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-500" />
                <a href="mailto:support@motivatefitness.store" className="hover:text-orange-500 transition-colors">
                  support@motivatefitness.store
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-500" />
                <a href="tel:1-800-555-0199" className="hover:text-orange-500 transition-colors">
                  1-800-555-0199
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-orange-500 mt-1" />
                <span>123 Fitness Ave<br />Los Angeles, CA 90210</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-zinc-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-zinc-500">
            © 2024 MotivateFitness. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-zinc-500">
            <a href="#" className="hover:text-orange-500 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}