import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem } from './cartStore';

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  shippingAddress: string;
  paymentMethod: string;
}

interface OrderStore {
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'date' | 'status'>) => Order;
  getOrders: () => Order[];
}

export const useOrderStore = create<OrderStore>()(
  persist(
    (set, get) => ({
      orders: [],
      addOrder: (orderData) => {
        const newOrder: Order = {
          ...orderData,
          id: `ORD-${Date.now()}`,
          date: new Date().toISOString(),
          status: 'processing',
        };
        set({ orders: [newOrder, ...get().orders] });
        return newOrder;
      },
      getOrders: () => get().orders,
    }),
    {
      name: 'motivationfitness-orders',
    }
  )
);
