export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  description: string;
  features: string[];
  variants?: { name: string; price?: number }[];
  rating: number;
  reviewCount: number;
  reviews: Review[];
  inStock: boolean;
  badge?: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
}

export const categories = [
  'All',
  'Dumbbells',
  'Barbells',
  'Kettlebells',
  'Weight Plates',
  'Resistance Bands',
  'Benches',
  'Squat Racks',
  'Yoga & Mats',
  'Accessories',
];

export const products: Product[] = [
  // Prices are intentionally set to be very budget-friendly for a wider audience.
  {
    id: 'hex-dumbbell-set',
    name: 'Pro Hex Dumbbell Set',
    category: 'Dumbbells',
    price: 14.99,
    originalPrice: 29.99,
    image: 'https://images.unsplash.com/photo-1586401100295-7a8096fd231a?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1586401100295-7a8096fd231a?w=800&h=800&fit=crop',
      'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=800&h=800&fit=crop',
    ],
    description: 'Premium rubber-coated hex dumbbells designed for serious lifters. The hexagonal shape prevents rolling and provides stability during your workout. Features ergonomic chrome handles with medium knurling for secure grip.',
    features: [
      'Rubber-coated heads prevent floor damage',
      'Chrome contoured handles',
      'Hexagonal shape prevents rolling',
      'Commercial-grade quality',
      'Sold as a pair',
    ],
    variants: [
      { name: '5-25 lbs Set', price: 14.99 },
      { name: '5-50 lbs Set', price: 24.99 },
      { name: '55-100 lbs Set', price: 39.99 },
    ],
    rating: 4.8,
    reviewCount: 234,
    reviews: [
      { id: '1', author: 'Mike T.', rating: 5, date: '2024-01-15', comment: 'Excellent quality, the rubber coating is durable and the handles feel great.', verified: true },
      { id: '2', author: 'Sarah K.', rating: 5, date: '2024-01-10', comment: 'Perfect for my home gym. Worth every penny!', verified: true },
      { id: '3', author: 'James R.', rating: 4, date: '2024-01-05', comment: 'Great dumbbells, shipping was fast. Minor rubber smell initially.', verified: true },
    ],
    inStock: true,
    badge: 'Best Seller',
  },
  {
    id: 'olympic-barbell',
    name: 'Olympic Power Barbell',
    category: 'Barbells',
    price: 19.99,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&h=800&fit=crop',
      'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&h=800&fit=crop',
    ],
    description: 'Competition-grade Olympic barbell built for maximum performance. Features precision needle bearings for smooth rotation and aggressive knurling for secure grip during heavy lifts.',
    features: [
      '20kg (45lbs) standard weight',
      '2200mm total length',
      '28mm shaft diameter',
      '190,000 PSI tensile strength',
      'Needle bearing sleeves',
      'Hard chrome finish',
    ],
    variants: [
      { name: 'Standard (20kg)', price: 19.99 },
      { name: 'Women\'s (15kg)', price: 16.99 },
    ],
    rating: 4.9,
    reviewCount: 189,
    reviews: [
      { id: '1', author: 'Chris P.', rating: 5, date: '2024-01-20', comment: 'The spin on this bar is incredible. Perfect for Olympic lifts.', verified: true },
      { id: '2', author: 'Amanda L.', rating: 5, date: '2024-01-18', comment: 'Finally a quality bar at a reasonable price. Highly recommend!', verified: true },
    ],
    inStock: true,
    badge: 'Pro Choice',
  },
  {
    id: 'competition-kettlebell',
    name: 'Competition Steel Kettlebell',
    category: 'Kettlebells',
    price: 6.99,
    image: 'https://images.unsplash.com/photo-1517344884509-a0c97ec11bcc?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1517344884509-a0c97ec11bcc?w=800&h=800&fit=crop',
    ],
    description: 'Professional-grade steel kettlebells with uniform size across all weights. Color-coded for easy identification during workouts. Perfect for competition training and serious strength work.',
    features: [
      'Steel construction',
      'Competition standard size',
      'Color-coded by weight',
      'Powder-coated finish',
      'Wide handle for two-hand grip',
    ],
    variants: [
      { name: '8kg (18lbs)', price: 4.49 },
      { name: '12kg (26lbs)', price: 5.49 },
      { name: '16kg (35lbs)', price: 6.99 },
      { name: '24kg (53lbs)', price: 8.99 },
      { name: '32kg (70lbs)', price: 10.99 },
    ],
    rating: 4.7,
    reviewCount: 156,
    reviews: [
      { id: '1', author: 'Tom H.', rating: 5, date: '2024-01-12', comment: 'Perfect balance and the handle is smooth but grippy.', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'bumper-plates-set',
    name: 'Olympic Bumper Plates Set',
    category: 'Weight Plates',
    price: 24.99,
    originalPrice: 49.99,
    image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800&h=800&fit=crop',
    ],
    description: 'High-density rubber bumper plates designed for Olympic lifting. Can be safely dropped from overhead. Color-coded following international standards.',
    features: [
      'Virgin rubber construction',
      'Steel insert hub',
      'Olympic 2" hole',
      'IWF color coding',
      'Low bounce design',
      '3-year warranty',
    ],
    variants: [
      { name: '160 lbs Set', price: 24.99 },
      { name: '260 lbs Set', price: 34.99 },
      { name: '370 lbs Set', price: 44.99 },
    ],
    rating: 4.8,
    reviewCount: 98,
    reviews: [
      { id: '1', author: 'Derek M.', rating: 5, date: '2024-01-08', comment: 'Great quality bumpers at an amazing price. Very minimal odor.', verified: true },
    ],
    inStock: true,
    badge: 'Sale',
  },
  {
    id: 'resistance-bands-set',
    name: 'Power Resistance Band Set',
    category: 'Resistance Bands',
    price: 4.99,
    image: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=800&h=800&fit=crop',
    ],
    description: 'Complete set of layered latex resistance bands for strength training, mobility work, and assisted exercises. Includes 5 bands of varying resistance levels.',
    features: [
      '5 resistance levels (5-150 lbs)',
      'Natural latex construction',
      'Color-coded by resistance',
      'Includes door anchor',
      'Carrying bag included',
    ],
    rating: 4.6,
    reviewCount: 312,
    reviews: [
      { id: '1', author: 'Lisa M.', rating: 5, date: '2024-01-22', comment: 'Perfect for home workouts and travel. Great quality!', verified: true },
      { id: '2', author: 'John D.', rating: 4, date: '2024-01-19', comment: 'Good variety of resistance. Use them daily for warmups.', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'adjustable-bench',
    name: 'Pro Adjustable Weight Bench',
    category: 'Benches',
    price: 29.99,
    image: 'https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=800&h=800&fit=crop',
    ],
    description: 'Commercial-grade adjustable bench with 7 back positions and 3 seat positions. Heavy-duty steel frame supports up to 1000 lbs. Perfect for flat, incline, and decline exercises.',
    features: [
      '7 back angle positions',
      '3 seat positions',
      '1000 lb weight capacity',
      'Heavy-gauge steel frame',
      'High-density foam padding',
      'Transport wheels',
    ],
    rating: 4.9,
    reviewCount: 167,
    reviews: [
      { id: '1', author: 'Ryan S.', rating: 5, date: '2024-01-25', comment: 'Rock solid bench. The adjustments are smooth and lock securely.', verified: true },
    ],
    inStock: true,
    badge: 'Top Rated',
  },
  {
    id: 'power-rack',
    name: 'Elite Power Rack System',
    category: 'Squat Racks',
    price: 59.99,
    originalPrice: 99.99,
    image: 'https://images.unsplash.com/photo-1534368270820-9de3d8053204?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1534368270820-9de3d8053204?w=800&h=800&fit=crop',
    ],
    description: 'Full-featured power rack with pull-up bar, safety spotter arms, and J-hooks. Built with 11-gauge steel for maximum stability during heavy lifts.',
    features: [
      '11-gauge steel construction',
      '1000 lb capacity',
      'Westside hole spacing',
      'Multi-grip pull-up bar',
      'Band pegs included',
      'Includes J-hooks & safeties',
    ],
    rating: 4.8,
    reviewCount: 89,
    reviews: [
      { id: '1', author: 'Marcus J.', rating: 5, date: '2024-01-14', comment: 'This rack is a beast! Super sturdy and has everything you need.', verified: true },
    ],
    inStock: true,
    badge: 'Sale',
  },
  {
    id: 'premium-yoga-mat',
    name: 'Premium Performance Yoga Mat',
    category: 'Yoga & Mats',
    price: 6.99,
    image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=800&h=800&fit=crop',
    ],
    description: 'Extra thick yoga mat with superior grip and cushioning. Made from eco-friendly TPE material. Perfect for yoga, Pilates, and floor exercises.',
    features: [
      '6mm thickness',
      'Non-slip texture both sides',
      'Eco-friendly TPE material',
      'Includes carrying strap',
      'Easy to clean',
      '72" x 24" size',
    ],
    variants: [
      { name: 'Black', price: 6.99 },
      { name: 'Navy Blue', price: 6.99 },
      { name: 'Dark Green', price: 6.99 },
    ],
    rating: 4.7,
    reviewCount: 203,
    reviews: [
      { id: '1', author: 'Emma W.', rating: 5, date: '2024-01-21', comment: 'Amazing grip even when sweaty. Love the thickness!', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'lifting-belt',
    name: 'Leather Powerlifting Belt',
    category: 'Accessories',
    price: 9.99,
    image: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=800&h=800&fit=crop',
    ],
    description: 'Competition-approved leather powerlifting belt with single prong buckle. 10mm thickness provides optimal support for heavy squats and deadlifts.',
    features: [
      'Genuine leather construction',
      '10mm thickness',
      '4" width throughout',
      'Single prong buckle',
      'IPF approved',
      'Break-in period required',
    ],
    variants: [
      { name: 'Small (26-32")', price: 9.99 },
      { name: 'Medium (30-36")', price: 9.99 },
      { name: 'Large (34-40")', price: 9.99 },
      { name: 'X-Large (38-44")', price: 9.99 },
    ],
    rating: 4.8,
    reviewCount: 145,
    reviews: [
      { id: '1', author: 'Steve B.', rating: 5, date: '2024-01-17', comment: 'Quality leather, feels like it will last forever.', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'gym-gloves',
    name: 'Pro Grip Training Gloves',
    category: 'Accessories',
    price: 3.99,
    image: 'https://images.unsplash.com/photo-1583454155184-870a1f63be09?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1583454155184-870a1f63be09?w=800&h=800&fit=crop',
    ],
    description: 'Premium weight lifting gloves with padded palms and breathable mesh backing. Wrist wrap provides extra support during heavy lifts.',
    features: [
      'Genuine leather palms',
      'Gel padding',
      'Breathable mesh back',
      'Integrated wrist wrap',
      'Pull tab for easy removal',
    ],
    variants: [
      { name: 'Small', price: 3.99 },
      { name: 'Medium', price: 3.99 },
      { name: 'Large', price: 3.99 },
      { name: 'X-Large', price: 3.99 },
    ],
    rating: 4.5,
    reviewCount: 278,
    reviews: [
      { id: '1', author: 'Alex K.', rating: 5, date: '2024-01-23', comment: 'Great grip and the wrist support is a nice bonus.', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'foam-roller',
    name: 'High-Density Foam Roller',
    category: 'Accessories',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&h=800&fit=crop',
    ],
    description: 'Professional-grade foam roller for muscle recovery and myofascial release. High-density EVA foam maintains shape through heavy use.',
    features: [
      'High-density EVA foam',
      'Textured surface',
      '18" length',
      'Maintains shape',
      'Easy to clean',
    ],
    rating: 4.6,
    reviewCount: 189,
    reviews: [
      { id: '1', author: 'Nina P.', rating: 4, date: '2024-01-11', comment: 'Good firmness for deep tissue work. Helps with recovery.', verified: true },
    ],
    inStock: true,
  },
  {
    id: 'ab-roller',
    name: 'Pro Ab Roller Wheel',
    category: 'Accessories',
    price: 5.99,
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800&h=800&fit=crop',
    ],
    description: 'Ergonomic ab roller with wide wheel for stability and foam handles for comfort. Includes knee pad for cushioned support.',
    features: [
      'Wide non-slip wheel',
      'Foam grip handles',
      'Steel core construction',
      'Includes knee pad',
      'Suitable for all levels',
    ],
    rating: 4.4,
    reviewCount: 156,
    reviews: [
      { id: '1', author: 'Carlos R.', rating: 5, date: '2024-01-09', comment: 'Simple but effective. Great for core workouts!', verified: true },
    ],
    inStock: true,
  },
];

export const getProductById = (id: string): Product | undefined => {
  return products.find((p) => p.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  if (category === 'All') return products;
  return products.filter((p) => p.category === category);
};
