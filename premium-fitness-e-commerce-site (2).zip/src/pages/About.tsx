import { Target, Award, Users, Truck, Shield, Headphones } from 'lucide-react';
import { Link } from 'react-router-dom';

export function About() {
  return (
    <div className="bg-zinc-950 min-h-screen text-white">
      {/* Hero */}
      <section className="relative py-24">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1920&h=800&fit=crop)',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/90 to-zinc-950/70" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Built for{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-red-600">
                Performance
              </span>
            </h1>
            <p className="text-xl text-zinc-400 leading-relaxed">
              At MotivateFitness, we believe every athlete deserves access to premium equipment.
              From garage gym warriors to elite competitors, we equip those who dare to push limits.
            </p>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-orange-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Target className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-xl font-bold mb-4">Our Mission</h3>
              <p className="text-zinc-400">
                To democratize access to professional-grade fitness equipment, empowering 
                athletes at every level to achieve their full potential.
              </p>
            </div>
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-orange-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Award className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-xl font-bold mb-4">Our Standards</h3>
              <p className="text-zinc-400">
                Every product is rigorously tested to meet commercial-grade specifications. 
                We don't compromise on quality, ever.
              </p>
            </div>
            <div className="text-center p-8">
              <div className="w-16 h-16 bg-orange-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-xl font-bold mb-4">Our Community</h3>
              <p className="text-zinc-400">
                Join over 50,000 athletes who trust MotivationFitness. From beginners to Olympians, 
                we're proud to support every fitness journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-zinc-400">
                <p>
                  MotivationFitness was born in 2018 from a simple frustration: why should quality 
                  gym equipment cost a fortune? Our founders, both competitive powerlifters, 
                  saw an opportunity to bridge the gap between commercial-grade equipment 
                  and home gym affordability.
                </p>
                <p>
                  Starting from a small warehouse in Los Angeles, we partnered directly with 
                  manufacturers to eliminate middlemen and pass savings to our customers. 
                  Today, we've equipped over 100,000 home and commercial gyms worldwide.
                </p>
                <p>
                  Our commitment remains unchanged: deliver the best equipment at fair prices, 
                  backed by industry-leading customer service and warranties.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1534368270820-9de3d8053204?w=800&h=600&fit=crop"
                alt="MotivationFitness Gym"
                className="rounded-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-orange-500 to-red-600 text-white p-6 rounded-xl">
                <p className="text-4xl font-bold">6+</p>
                <p className="text-sm">Years of Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-gradient-to-r from-orange-600 to-red-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl md:text-5xl font-bold mb-2">100K+</p>
              <p className="text-orange-200">Gyms Equipped</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold mb-2">50K+</p>
              <p className="text-orange-200">Happy Customers</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold mb-2">500+</p>
              <p className="text-orange-200">Products</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold mb-2">4.8</p>
              <p className="text-orange-200">Average Rating</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Why Choose MotivationFitness?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-zinc-800 rounded-2xl p-8">
              <Truck className="w-10 h-10 text-orange-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">Free Shipping</h3>
              <p className="text-zinc-400">
                Free ground shipping on all orders over $99. Most items ship within 2 business days.
              </p>
            </div>
            <div className="bg-zinc-800 rounded-2xl p-8">
              <Shield className="w-10 h-10 text-orange-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">Lifetime Warranty</h3>
              <p className="text-zinc-400">
                We stand behind our products with industry-leading warranties up to lifetime coverage.
              </p>
            </div>
            <div className="bg-zinc-800 rounded-2xl p-8">
              <Headphones className="w-10 h-10 text-orange-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">Expert Support</h3>
              <p className="text-zinc-400">
                Our team of fitness enthusiasts is available 24/7 to answer questions and provide guidance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Build Your Dream Gym?
          </h2>
          <p className="text-zinc-400 text-lg mb-8">
            Browse our collection of premium equipment and start your fitness journey today.
          </p>
          <Link
            to="/shop"
            className="inline-flex items-center justify-center bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold px-8 py-4 rounded-xl transition-all"
          >
            Shop Now
          </Link>
        </div>
      </section>
    </div>
  );
}
