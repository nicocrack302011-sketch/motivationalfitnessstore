import { useState } from 'react';
import { Mail, Phone, MapPin, MessageCircle, ChevronDown, ChevronUp, Send, Package, RotateCcw, Truck } from 'lucide-react';

const faqs = [
  {
    question: 'How long does shipping take?',
    answer: 'Most orders ship within 2 business days. Standard ground shipping typically takes 5-7 business days. Expedited options are available at checkout for faster delivery.',
  },
  {
    question: 'What is your return policy?',
    answer: 'We offer a 30-day return policy on all unused items in original packaging. For defective items, we provide free return shipping and full refunds or replacements.',
  },
  {
    question: 'Do you offer financing options?',
    answer: 'Yes! We partner with Affirm to offer flexible payment plans. You can split your purchase into 3, 6, or 12 monthly payments. Apply at checkout to see your options.',
  },
  {
    question: 'What warranty do you provide?',
    answer: 'Our warranties vary by product category. Barbells and plates come with a lifetime warranty. Racks and benches have 10-year structural warranties. Accessories typically have 2-year coverage.',
  },
  {
    question: 'Do you ship internationally?',
    answer: 'Currently, we ship to the United States and Canada. International shipping to additional countries is coming soon. Sign up for our newsletter to be notified.',
  },
  {
    question: 'Can I modify or cancel my order?',
    answer: 'Orders can be modified or cancelled within 2 hours of placement. After that, orders enter processing and changes may not be possible. Contact support immediately for assistance.',
  },
  {
    question: 'How do I track my order?',
    answer: 'Once your order ships, you\'ll receive an email with tracking information. You can also log into your account to view order status and tracking details.',
  },
  {
    question: 'Do you offer bulk or commercial pricing?',
    answer: 'Yes! We offer special pricing for gyms, schools, and large orders. Contact our sales team at commercial@motivatefitness.store for a custom quote.',
  },
];

export function Support() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    orderNumber: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="bg-zinc-950 min-h-screen text-white">
      {/* Hero */}
      <section className="bg-zinc-900 border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Customer Support</h1>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            We're here to help. Find answers to common questions or reach out to our team.
          </p>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-12 border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a href="#faq" className="bg-zinc-900 rounded-xl p-6 text-center hover:bg-zinc-800 transition-colors">
              <MessageCircle className="w-8 h-8 text-orange-500 mx-auto mb-3" />
              <h3 className="font-semibold">FAQs</h3>
              <p className="text-sm text-zinc-500">Common questions</p>
            </a>
            <a href="#shipping" className="bg-zinc-900 rounded-xl p-6 text-center hover:bg-zinc-800 transition-colors">
              <Truck className="w-8 h-8 text-orange-500 mx-auto mb-3" />
              <h3 className="font-semibold">Shipping</h3>
              <p className="text-sm text-zinc-500">Delivery info</p>
            </a>
            <a href="#returns" className="bg-zinc-900 rounded-xl p-6 text-center hover:bg-zinc-800 transition-colors">
              <RotateCcw className="w-8 h-8 text-orange-500 mx-auto mb-3" />
              <h3 className="font-semibold">Returns</h3>
              <p className="text-sm text-zinc-500">Easy returns</p>
            </a>
            <a href="#contact" className="bg-zinc-900 rounded-xl p-6 text-center hover:bg-zinc-800 transition-colors">
              <Mail className="w-8 h-8 text-orange-500 mx-auto mb-3" />
              <h3 className="font-semibold">Contact</h3>
              <p className="text-sm text-zinc-500">Get in touch</p>
            </a>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-zinc-900 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <span className="font-semibold pr-4">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp className="w-5 h-5 text-orange-500 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-zinc-500 flex-shrink-0" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-6">
                    <p className="text-zinc-400">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shipping & Returns Info */}
      <section className="py-16 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div id="shipping">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <Package className="w-7 h-7 text-orange-500" />
                Shipping Information
              </h2>
              <div className="space-y-4 text-zinc-400">
                <p>
                  <strong className="text-white">Free Standard Shipping:</strong> On all orders over $99 (continental US)
                </p>
                <p>
                  <strong className="text-white">Processing Time:</strong> Most orders ship within 2 business days
                </p>
                <p>
                  <strong className="text-white">Delivery Times:</strong>
                </p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Standard Ground: 5-7 business days</li>
                  <li>Expedited: 2-3 business days</li>
                  <li>Express: Next business day</li>
                </ul>
                <p>
                  <strong className="text-white">Freight Items:</strong> Large items like racks and heavy plate sets ship via freight. You'll receive scheduling details after shipment.
                </p>
              </div>
            </div>
            <div id="returns">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <RotateCcw className="w-7 h-7 text-orange-500" />
                Returns & Exchanges
              </h2>
              <div className="space-y-4 text-zinc-400">
                <p>
                  <strong className="text-white">30-Day Returns:</strong> Return unused items in original packaging within 30 days for a full refund.
                </p>
                <p>
                  <strong className="text-white">Defective Items:</strong> We cover return shipping for defective products and offer replacements or refunds.
                </p>
                <p>
                  <strong className="text-white">How to Return:</strong>
                </p>
                <ol className="list-decimal pl-6 space-y-1">
                  <li>Contact support to initiate return</li>
                  <li>Receive prepaid shipping label (if applicable)</li>
                  <li>Pack items securely in original packaging</li>
                  <li>Refund processed within 5-7 business days of receipt</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-3xl font-bold mb-6">Get in Touch</h2>
              <p className="text-zinc-400 mb-8">
                Have a question that's not answered above? Our support team is available 24/7 to help.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Email Us</h3>
                    <a href="mailto:support@motivationfitness.com" className="text-zinc-400 hover:text-orange-500">
                      support@motivationfitness.com
                    </a>
                    <p className="text-sm text-zinc-500">We respond within 24 hours</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Call Us</h3>
                    <a href="tel:1-800-555-0199" className="text-zinc-400 hover:text-orange-500">
                      1-800-555-0199
                    </a>
                    <p className="text-sm text-zinc-500">Mon-Fri: 8am-8pm EST</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Visit Us</h3>
                    <p className="text-zinc-400">
                      123 Fitness Ave<br />
                      Los Angeles, CA 90210
                    </p>
                    <p className="text-sm text-zinc-500">Showroom by appointment</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-zinc-900 rounded-2xl p-8">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Send className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Message Sent!</h3>
                  <p className="text-zinc-400">
                    Thank you for reaching out. We'll get back to you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <h3 className="text-xl font-bold mb-4">Send us a Message</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Name</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 focus:outline-none focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 focus:outline-none focus:border-orange-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Order Number (Optional)</label>
                    <input
                      type="text"
                      value={formData.orderNumber}
                      onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                      placeholder="ORD-123456789"
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Subject</label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      required
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 focus:outline-none focus:border-orange-500"
                    >
                      <option value="">Select a topic</option>
                      <option value="order">Order Status</option>
                      <option value="shipping">Shipping Question</option>
                      <option value="return">Return/Exchange</option>
                      <option value="product">Product Information</option>
                      <option value="warranty">Warranty Claim</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Message</label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                      rows={4}
                      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 focus:outline-none focus:border-orange-500 resize-none"
                      placeholder="How can we help you?"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
